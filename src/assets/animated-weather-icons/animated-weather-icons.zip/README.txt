A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/RxJJgQ.

 Based on dribbble shot https://dribbble.com/shots/2097042-Widget-Weather by kylor